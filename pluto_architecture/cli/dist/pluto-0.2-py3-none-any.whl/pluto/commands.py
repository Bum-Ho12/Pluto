'''file that executes commands'''
def check_cmd():
    '''test command'''
    print("Running Pluto's check command.")
